from aiogram.types import InlineKeyboardButton,InlineKeyboardMarkup
# from keyboards.inline.callback_data import course_callback, book_callback
Settings= InlineKeyboardMarkup(
    inline_keyboard=[
        [
           InlineKeyboardButton(text="Tilni sozlash") 
        ],
    ]
)