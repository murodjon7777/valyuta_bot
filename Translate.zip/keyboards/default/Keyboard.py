from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
menu = ReplyKeyboardMarkup(
    keyboard=[
        [ 
         KeyboardButton(text="uzbek"),
        KeyboardButton(text="russian"),
        KeyboardButton(text="english"),
        ],
        [
        KeyboardButton(text="french"),
        KeyboardButton(text="german"),
        KeyboardButton(text="arabic"),
        ],
        [ 
        KeyboardButton(text="korean"), 
        KeyboardButton(text="italian") ,
        KeyboardButton(text="spanish") ,
        ]
      
    ],
    resize_keyboard=True
)