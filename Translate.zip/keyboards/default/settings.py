from aiogram.types import ReplyKeyboardMarkup,KeyboardButton
setting=ReplyKeyboardMarkup(
  keyboard = [
        [
            KeyboardButton(text="Tilni sozlash"),
         ],
    ],
    resize_keyboard=True
  
)